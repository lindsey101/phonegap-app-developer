(function(window, undefined) {

  var jimLinks = {
    "316ee6af-cd6f-4d13-8a44-0a441fe97586" : {
      "Image_12" : [
        "c7ff9220-7a28-410c-b2e1-82d4d91124f5"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c7ff9220-7a28-410c-b2e1-82d4d91124f5" : {
      "Image_12" : [
        "b2ad6bbf-6e3c-435a-86c3-f0261ef59d42"
      ],
      "Text_2" : [
        "9f3f1e6b-a60c-4966-b5fa-c643d5a64d84"
      ],
      "Text_3" : [
        "fb6fa2de-42ed-4b47-b6c5-50a12d94ed61"
      ],
      "Text_4" : [
        "316ee6af-cd6f-4d13-8a44-0a441fe97586"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "9f3f1e6b-a60c-4966-b5fa-c643d5a64d84" : {
      "Image_12" : [
        "c7ff9220-7a28-410c-b2e1-82d4d91124f5"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "ebaa4a95-47fa-4b4f-9415-a30bad75b399" : {
      "Image_12" : [
        "b2ad6bbf-6e3c-435a-86c3-f0261ef59d42"
      ]
    },
    "b2ad6bbf-6e3c-435a-86c3-f0261ef59d42" : {
      "Rounded_Label" : [
        "c7ff9220-7a28-410c-b2e1-82d4d91124f5"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rounded_Label_2" : [
        "ebaa4a95-47fa-4b4f-9415-a30bad75b399"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "fb6fa2de-42ed-4b47-b6c5-50a12d94ed61" : {
      "Image_12" : [
        "c7ff9220-7a28-410c-b2e1-82d4d91124f5"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Label_25" : [
        "b2ad6bbf-6e3c-435a-86c3-f0261ef59d42"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);