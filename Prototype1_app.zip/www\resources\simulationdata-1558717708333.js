function initData() {
  jimData.variables["test"] = "time cards";
  jimData.isInitialized = true;
}