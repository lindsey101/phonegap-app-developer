(function(window, undefined) {
  var dictionary = {
    "316ee6af-cd6f-4d13-8a44-0a441fe97586": "Jesus",
    "c7ff9220-7a28-410c-b2e1-82d4d91124f5": "Technicians",
    "9f3f1e6b-a60c-4966-b5fa-c643d5a64d84": "Gabriel",
    "ebaa4a95-47fa-4b4f-9415-a30bad75b399": "Misc. Doc",
    "b2ad6bbf-6e3c-435a-86c3-f0261ef59d42": "Welcome",
    "fb6fa2de-42ed-4b47-b6c5-50a12d94ed61": "Aurelio",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login Screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);